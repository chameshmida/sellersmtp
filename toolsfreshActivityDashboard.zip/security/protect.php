<?php
error_reporting(0);

$user = $_POST['user'];
$pass = $_POST['pass'];

if($user == "xproad" && $pass == "xproad")
{

}
else
{
    if(isset($_POST))
    {
        $form = '
        <html>
        <head>
        <title>Tools Fresh - Activity Traffics Dashboard</title>
        <link href="assets/css/styleProtect.css" rel="stylesheet" type="text/css" />
        <link rel="shortcut icon" href="assets/img/favicon.png" />
        </head>
        <style>
        #user {
            opacity: 0;
            width: 0;
            float: left; /* Reposition so the validation message shows over the label */
          }
        #pass {
            opacity: 0;
            width: 0;
            float: left; /* Reposition so the validation message shows over the label */
          }
        #submitActivity {
            opacity: 0;
            width: 0;
            float: left; /* Reposition so the validation message shows over the label */
          }

        </style>

        <body>

        <div class="flex-container">
        <div class="text-center">
          <h1>
            <span class="fade-in" id="digit1">4</span>
            <span class="fade-in" id="digit2">0</span>
            <span class="fade-in" id="digit3">4</span>
          </h1>
        </div>
      </div>



        <form method="post" action="' . $_SERVER['PHP_SELF'] . '">
            <input type="text" name="user" id="user"><br/> <br>

            <input type="password" name="pass" id="pass"><br/><br>
            <input type="submit" name="submit" value="Move To Activity" id="submitActivity">
        </form>
        </body>
        </html>
    ';
    die($form);

    }
}
?>
