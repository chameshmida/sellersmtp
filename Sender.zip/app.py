from datetime import timedelta, datetime
from flask import Flask, request, jsonify
from flask_cors import CORS

import requests as req
from flask import Flask
import threading
import random, string

import base64
import datetime
import glob
import os
import smtplib, ssl
import sys
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import make_msgid
from email.header import Header
from multiprocessing.dummy import Pool
from random import choice
from colorama import Fore, Style

from email.mime.base import MIMEBase
from email import encoders
import re
from waitress import serve


import time

app = Flask(__name__)
#cors = CORS(app, resources={r"/sender/*": {"origins": "*"}})
cors = CORS(app, resources={r"/sender/*": {"origins": ["http://toolsfresh.org", "http://www.toolsfresh.org", "https://toolsfresh.org", "https://www.toolsfresh.org"]}})

@app.route("/sender/testemail", methods=['POST'])
def checkRequest():
    start_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    try:
        if request.method == 'POST':
            emailTest = request.form['emailtest']
            #emailTest = emailTest.replace('"', '')
            smtp, mailserver = getSmtpAndConnection()
            return sendTestEmail(emailTest, smtp, mailserver, start_time)
    except Exception as e:
        message = "❗️ Failed to check request Api error\nTool: Seller Mailgun Website.\n"+str(e)
        sendTelgMessage(message)

@app.route("/sender/totaltest", methods=['GET'])
def showTotalTest():
    try:
        if request.method == 'GET':
            with open('emails.txt', 'r') as f:
                data = f.read()
                lines = data.splitlines()
                totalTest = len(lines)
                totalTest = int(totalTest)
                return jsonify(totalTest)
        else:
            return jsonify('HTTP/1.0 404 Not Found')

    except Exception as e:
        message = '❗️ Error Showing Total Test.\nTool: Seller Mailgun Website.\n' + str(e)
        sendTelgMessage(message)
        return jsonify('HTTP/1.0 404 Not Found')

def getSmtpAndConnection():
    try:
        smtp = random.choice(open('config/Smtp.txt').readlines())
        host, port, user, pas = smtp.strip().split("|")
    
        context = ssl.create_default_context()
        mailserver = smtplib.SMTP_SSL(host, int(port), context=context)
        mailserver.ehlo('mail.toolsfresh.org')       ##############################
        mailserver.login(user, pas)
    
        return smtp, mailserver
    
    except Exception as e:
        message = "⚠️ Failed to login to SMTP Server\nTool: Seller Mailgun Website.\n"+str(e)
        sendTelgMessage(message)

def sendTestEmail(emailTest, smtp, mailserver, start_time):
    try:
        host, port, user, pas = smtp.strip().split("|")

         ######################  this section is for Letter Randomizer ###############################
        all_letters = glob.glob('config/letter/*.html')
        _letter = choice(all_letters)
        with open(_letter, 'r', encoding='utf-8') as (f):
            r_letter = f.read()
            r_letter = r_letter.replace('##random_string##',
                                    ''.join(random.sample(string.ascii_lowercase + string.digits, 7)))
            r_letter = r_letter.replace('##time##', datetime.datetime.now().strftime('%H:%M:%S'))
            r_letter = r_letter.replace('##date##', datetime.datetime.now().strftime('%Y-%m-%d'))
            r_letter = r_letter.replace('##date&time##', datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
            r_letter = r_letter.replace('##random_number##', str(random.randint(0, 9999999)))
            letter = r_letter

        ######################  this section is for Subject Randomizer ###############################
        Subject = random.choice(open('config/Subject.txt').readlines())
        r_subject = Subject.replace('##random_string##', ''.join(random.sample(string.ascii_lowercase + string.digits, 7)))
        r_subject = Subject.replace('##random_string##', ''.join(random.sample(string.ascii_lowercase + string.digits, 7)))
        r_subject = r_subject.replace('##time##', datetime.datetime.now().strftime('%H:%M:%S'))
        r_subject = r_subject.replace('##user##', user)
        r_subject = r_subject.replace('##date##', datetime.datetime.now().strftime('%Y-%m-%d'))
        r_subject = r_subject.replace('##date&time##', datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        r_subject = r_subject.replace('##random_number##', str(random.randint(0, 9999999)))
         #   Subject = r_subject
        message_bytes = r_subject.encode('latin1')
        base64_bytes = base64.b64encode(message_bytes)
        base64_message = base64_bytes.decode('ascii')
        
        r_subject = base64_message
        Subject = r_subject


        msg = MIMEText(letter, 'html', 'utf-8')
        msg['To'] = emailTest
        msg['From'] = "Seller Mailgun <sellermailgun@mail.toolsfresh.org>"
        msg['Subject'] = '=?UTF-8?B?{}?='.format(Subject)
        msg.add_header('reply-to', 'sellermailgun@toolsfresh.org')
        msg['Date'] = datetime.datetime.now().strftime('%a, %d %b %Y %H:%M:%S GMT')
        msg['Message-ID'] = make_msgid(domain="mail.toolsfresh.org") #################
        msg['X-Mailer'] = 'Microsoft CDO for Windows 2000'
            
        mailserver.sendmail("sellermailgun@toolsfresh.org", emailTest, msg.as_string())
        mailserver.quit()

        with open('emails.txt', 'a') as (f):
            f.write(emailTest + '\n')
        message = '✅ New Test Email Sent to: ' + emailTest +'\n Tool: Seller Mailgun Website at '+str(start_time)+'.'
        sendTelgMessage(message)
        
        return jsonify({'status': 'success', 'message': 'Test Email Sent Successfully'}), 200
    except Exception as e:
        message = 'Failed to send Test Email to: ' + emailTest + 'at: ' +str(start_time)+'\n Tool: Seller Mailgun Website.\n' + str(e)
        sendTelgMessage(message)



def sendTelgMessage(message):
    chat_id = "1236750144"
    token = '6723476585:AAFQHdNdj0npp1vsvyiq3rJedjh5Fc2NNWo'
    try:
        req.get('https://api.telegram.org/bot'+token+'/sendMessage?chat_id='+chat_id+'&parse_mode=html&text='+str(message))
    except Exception as e:
        print(e)

if __name__ == "__main__":
    #app.run(host="0.0.0.0", port=5000, debug=True, ssl_context=("flask_ssl/cert.pem", "flask_ssl/key.pem"))
    #serve(app, host='0.0.0.0', port=80, threads=1) #WAITRESS!
    app.run(host="0.0.0.0", port=5000, debug=True, ssl_context=("/etc/letsencrypt/live/toolsfresh.live/fullchain.pem", "/etc/letsencrypt/live/toolsfresh.live/privkey.pem"))