<?php
require 'security/protect.php';
?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title>XProad Traffics</title>
  <link rel="stylesheet" type="text/css"
    href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css"
    href="https://pixinvent.com/stack-responsive-bootstrap-4-admin-template/app-assets/css/bootstrap-extended.min.css">
  <link rel="stylesheet" type="text/css"
    href="https://pixinvent.com/stack-responsive-bootstrap-4-admin-template/app-assets/fonts/simple-line-icons/style.min.css">
  <link rel="stylesheet" type="text/css"
    href="https://pixinvent.com/stack-responsive-bootstrap-4-admin-template/app-assets/css/colors.min.css">
  <link rel="stylesheet" type="text/css"
    href="https://pixinvent.com/stack-responsive-bootstrap-4-admin-template/app-assets/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat&display=swap" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet" type="text/css" />

  <script src="assets/js/script.js"></script>

  <script>window.onload = getGatherTrafficsInfos</script>

</head>

<body>

  <!-- Image + Dashboard title
   -->
  <div class="container-fluid">
    <div class="row justify-content-center">
      <h3 class="mb-3"><img class="imgShadow" src="assets/img/tools-fresh-photo.jpg" class="img-fluid mb-3" width="150px" height="150px">
        Tools Fresh Activity Traffics Dashboard<br><a href="https://t.me/toolsfresh"><img
            src="https://i.ibb.co/djFFN3g/1000x-removebg-preview.png"></a></h3>
    </div>
  </div>


<!--           Cards Elements of Statistiques -->

  <div class="container-fluid">
    <div class="row justify-content-center">

      <div class="col-xl-3 col-sm-6 col-12">
        <div class="card">
          <div class="card-content">
            <div class="card-body">
              <div class="media d-flex">
                <div class="align-self-center">
                  <i class="icon-graph blue font-large-2 float-left"></i>
                </div>
                <div class="media-body text-right">
                  <h3 id="totalTraffics"></h3>
                  <span>Total Activities</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="col-xl-3 col-sm-6 col-12">
        <div class="card">
          <div class="card-content">
            <div class="card-body">
              <div class="media d-flex">
                <div class="align-self-center">
                  <i class="icon-check warning font-large-2 float-left"></i>
                </div>
                <div class="media-body text-right">
                  <h3 id="uniqueTraffics"></h3>
                  <span>Unique Visitors</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

     

  <div class="container-fluid">
    <div class="row justify-content-center">


      <div class="col-xl-3 col-sm-6 col-12">
        <div class="card">
          <div class="card-content">
            <div class="card-body">
              <div class="media d-flex">
                <div class="align-self-center">
                  <i class="icon-user-follow blue font-large-2 float-left"></i>
                </div>
                <div class="media-body text-right">
                  <h3 id="joinTraffics"></h3>
                  <span>Join Clicks</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>


      <div class="col-xl-3 col-sm-6 col-12">
        <div class="card">
          <div class="card-content">
            <div class="card-body">
              <div class="media d-flex">
                <div class="align-self-center">
                  <i class="icon-volume-2 info font-large-2 float-left"></i>
                </div>
                <div class="media-body text-right">
                  <h3 id="notifTraffics"></h3>
                  <span>Activated Notification</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="col-xl-3 col-sm-6 col-12">
        <div class="card">
          <div class="card-content">
            <div class="card-body">
              <div class="media d-flex">
                <div class="align-self-center">
                  <i class="icon-cloud-download success font-large-2 float-left"></i>
                </div>
                <div class="media-body text-right">
                  <h3 id="unlockTraffics"></h3>
                  <span>Unlocked Download Link</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
      </div>
      </div>




  <!-- Tables of traffics with informations (Country|REFERER|ISP|UserAgent|IP|Status) -->

  <div class="container-fluid">
    <div class="row justify-content-center">


      <div class="container">
        <div class="header_wrap">
          <div class="num_rows">

            <div class="form-group">
              <!--		Show Numbers Of Rows 		-->
              <select onchange="filterMaxRows()" class="form-control" name="state" id="maxRows">


                <option value="10">10</option>
                <option value="15">15</option>
                <option value="20">20</option>
                <option value="50">50</option>
                <option value="70">70</option>
                <option value="100">100</option>
                <option value="5000">Show ALL Traffics</option>
              </select>

            </div>
          </div>
          <div class="tb_search">
            <input type="text" id="search_input_all" onkeyup="FilterkeyWord_all_table()" placeholder="Search.."
              class="form-control">
          </div>
        </div>
        <table class="table table-striped table-class table-sm" id="table-id">


          <thead>
            <tr>
              <th>COUNTRY</th>
              <th>REFERER</th>
              <th>ISP</th>
              <th>UA</th>
              <th>IP</th>
              <th>STATUS</th>
            </tr>
          </thead>
          <tbody id="tbody-id">


          <tbody>
        </table>

        <!--		Start Pagination -->

        <div class="container">
          <div class="row justify-content-center">
            <div class="pagination-container">
              <ul class="pagination" id="pagination">
                <li class="page-item"><a class="page-link" href="#" onclick="paginationOfTable(1, 10)">Previous</a></li>
                <li class="page-item"><a class="page-link" href="#" onclick="paginationOfTable(1, 10)">1</a></li>
                <li class="page-item"><a class="page-link" href="#" onclick="paginationOfTable(1, 10)">Next</a></li>
                <!-- Add more page links here as needed -->
              </ul>
            </div>
          </div>
        </div>



        <!-- 		End of Container -->


        <!-- END Tables of traffics with informations (Country|REFERER|ISP|UserAgent|IP|Status) -->


      </div>
    </div>


</body>

</html>
