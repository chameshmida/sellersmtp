function getGatherTrafficsInfos() {
  var totalTraffics = 0;
  var joinTraffics = 0;
  var notifTraffics = 0;
  var unlockTraffics = 0;
  var uniqueTraffics = 0;
  var table;
  table = document.getElementById("tbody-id");
  const visitorActivityFileUrl = "https://xproad2.pythonanywhere.com/toolsfresh/traffic/showall";
  const uniqueActivityFileUrl = "https://xproad2.pythonanywhere.com/toolsfresh/traffic/show-unique-visitor";

// totalTraffics File Fetching

fetch(visitorActivityFileUrl)
.then(response => response.json())
.then(data => {
  // Split the content into lines
  const lines = data.split('\n');
  
  // Process each line
  lines.forEach(line => {
    totalTraffics += 1;
    let country, referer, isp, ua, ip, status;
    [country, referer, isp, ua, ip, status] = line.split('|');

    if (line.includes('join')) {
      joinTraffics += 1;
    } else if (line.includes('activate')) {
      notifTraffics += 1;
    } else if (line.includes('unlock')) {
      unlockTraffics += 1;
    }

    // Auto Increment Table
    var trTable = document.createElement('tr');
    var tdCountry = document.createElement('td');
    var tdReferer = document.createElement('td');
    var tdIsp = document.createElement('td');
    var tdUa = document.createElement('td');
    var tdIp = document.createElement('td');
    var tdStatus = document.createElement('td');

    tdCountry.textContent = country;
    tdReferer.textContent = referer;
    tdIsp.textContent = isp;
    tdUa.textContent = ua;
    tdIp.textContent = ip;
    tdStatus.textContent = status;
    trTable.appendChild(tdCountry);
    trTable.appendChild(tdReferer);
    trTable.appendChild(tdIsp);
    trTable.appendChild(tdUa);
    trTable.appendChild(tdIp);
    trTable.appendChild(tdStatus);
    table.appendChild(trTable);


  });
  totalTraffics -= 1;

 /*  joinTraffics -= 1;
  notifTraffics -= 1;
  unlockTraffics -= 1;
 */
  var totalTrafficsHtml = document.getElementById('totalTraffics');

  var joinTrafficsHtml = document.getElementById('joinTraffics');
  var notifTrafficsHtml = document.getElementById('notifTraffics');
  var unlockTrafficsHtml = document.getElementById('unlockTraffics');

  if (totalTrafficsHtml) {
  var newText = document.createTextNode(totalTraffics);
  totalTrafficsHtml.appendChild(newText);
  }

  if (joinTrafficsHtml) {
    var newText = document.createTextNode(joinTraffics);
    joinTrafficsHtml.appendChild(newText);
    }
  
  if (notifTrafficsHtml) {
    var newText = document.createTextNode(notifTraffics);
    notifTrafficsHtml.appendChild(newText);
    }
  
  if (unlockTrafficsHtml) {
    var newText = document.createTextNode(unlockTraffics);
    unlockTrafficsHtml.appendChild(newText);
    }

})
.catch(error => console.error('Error fetching the Total results file', error));



// uniqueTraffics File Fetching

fetch(uniqueActivityFileUrl)
.then(response => response.json())
.then(data => {
  // Split the content into lines
  uniqueTraffics = data;
  var uniqueTrafficsHtml = document.getElementById('uniqueTraffics');
  if (uniqueTrafficsHtml) {
    var newText = document.createTextNode(uniqueTraffics);
    uniqueTrafficsHtml.appendChild(newText);
    }

})
.catch(error => console.error('Error fetching the Total results file', error));


}



function paginationOfTable(pageNumber, rowsPerPage) {
  var table = document.getElementById("table-id");
  var rows = table.getElementsByTagName("tr");
  var totalPages = Math.ceil(rows.length / rowsPerPage);

  var pagination = document.getElementById("pagination");
  pagination.innerHTML = '';

  var previousButton = document.createElement('li');
  var previousLink = document.createElement('a');
  previousLink.href = "#";
  previousLink.className = "page-link";
  previousLink.textContent = "Previous";
  previousLink.setAttribute("onclick", "paginationOfTable(" + (pageNumber - 1) + ", " + rowsPerPage + ")");
  previousButton.appendChild(previousLink);
  pagination.appendChild(previousButton);

  for (var i = 1; i <= totalPages; i++) {
    var li = document.createElement('li');
    var a = document.createElement('a');
    a.href = "#";
    a.className = "page-link";
    a.textContent = i;
    if (i === pageNumber) {
      a.classList.add('current-page'); // adding blue color to the current number
    }
    a.setAttribute("onclick", "paginationOfTable(" + i + ", " + rowsPerPage + ")");
    li.appendChild(a);
    pagination.appendChild(li);
  }

  var nextButton = document.createElement('li');
  var nextLink = document.createElement('a');
  nextLink.href = "#";
  nextLink.className = "page-link";
  nextLink.textContent = "Next";
  nextLink.setAttribute("onclick", "paginationOfTable(" + (pageNumber + 1) + ", " + rowsPerPage + ")");
  nextButton.appendChild(nextLink);
  pagination.appendChild(nextButton);

  var startIndex = (pageNumber - 1) * rowsPerPage;
  var endIndex = pageNumber * rowsPerPage;

  for (var i = 0; i < rows.length; i++) {
    if (i >= startIndex && i < endIndex) {
      rows[i].style.display = "";
    } else {
      rows[i].style.display = "none";
    }
  }
}






function FilterkeyWord_all_table() {
  // Declare variables
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("search_input_all");
  filter = input.value.toUpperCase();
  table = document.getElementById("table-id");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td");
    for (var j = 0; j < td.length; j++) {
      cell = tr[i].getElementsByTagName("td")[j];
      if (cell) {
        txtValue = cell.textContent || cell.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
          tr[i].style.display = "";
          break;
        } else {
          tr[i].style.display = "none";
        }
      }
    }
  }
}


function filterMaxRows() {
  // Declare Variable
  var input, filter, table, tr, i;
  input = document.getElementById("maxRows");
  filter = input.value;
  table = document.getElementById("table-id");
  tr = table.getElementsByTagName("tr");

  // Loop Throught the table tr and shows only value of maxRows

  for (i = 0; i < tr.length; i++) {
    if (i <= filter) {
      tr[i].style.display = "";
    } else {
      tr[i].style.display = "none";

    }

  }
}
