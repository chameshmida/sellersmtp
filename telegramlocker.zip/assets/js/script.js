$(document).ready(function(){
    $("#btn1").click(async function(){
      let referer = document.referrer;
      let status = "joinClick";

      await cloudflareWorkerGetIpInfo(referer, status);

      setTimeout(function() {
      $("button[type='submit']").removeAttr('disabled');
    }, 3000);
      $("#btn2").click(async function(){

        let status = "activateNotif";
        await cloudflareWorkerGetIpInfo(referer, status);

        setTimeout(function() {
          $("button[type='submit2']").removeAttr('disabled');
        }, 3000);
    });
    $("#btn3").click(async function(){

       let status = "unlockDownload";
       await cloudflareWorkerGetIpInfo(referer, status);

  });
    });
  });

async function cloudflareWorkerGetIpInfo(referer, status) {
  const url = `https://toolsfresh-join2unlock-getipinfo.xproadhmida.workers.dev/`;
  const response = await fetch(url);
  const data = await response.json();
  const { country, isp } = data;
  const userAgent = navigator.userAgent;
  console.log(country, referer, isp, userAgent, status);
  //sendActivityResultToApi(country, referer, isp, userAgent, ipAddress, status);
}

async function detectVisitorActivityOnLoad() {
  let referer = document.referrer;
  let status = "VISITOR";
  await cloudflareWorkerGetIpInfo(referer, status);
}

async function sendActivityResultToApi(country, referer, isp, userAgent, ipAddress, status) {
  var formData = new FormData();
  formData.append('country', country);
  formData.append('referer', referer);
  formData.append('isp', isp);
  formData.append('userAgent', userAgent);
  formData.append('ipAddr', ipAddress);
  formData.append('status', status);
  var url = "https://xproad2.pythonanywhere.com/toolsfresh/traffic/add";
  const response = await fetch(url, {
      method: 'POST',
      body: formData
  });
  const result = await response.json();
  //console.log(result);

}