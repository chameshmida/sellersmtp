<?php
session_start(); // OUVERTURE DE LA SESSION 
//error_reporting(0);

if (isset($_POST['generate'])){
    try {
        //$telegramLink = $_POST['telegram-link'];
        $linkToLock = $_POST['lock-link'];
        
        $response = createIndexHtml($linkToLock);
        echo '<script>alert("' . $response . '");</script>';
    } catch(Exception $e) {
        console.log($e);
    } 
}
function createRandomFolder() {
    $folderName = uniqid(); // Generate a unique folder name
    $folderPath = '../telegram/combo/' . $folderName; // Set the path to your desired directory
    
    mkdir($folderPath); // Create the folder
    return $folderPath; // Return the path to the created folder
}

function isFolderExist($folderName, $directoryPath) {
    $folderPath = $directoryPath . '/' . $folderName; // Set the path to the folder
    
    if (file_exists($folderPath) && is_dir($folderPath)) {
        return true; // Return true if the folder exists
    } else {
        return false; // Return false if the folder does not exist
    }
}

function createIndexHtml($linkToLock) {
    
    $html = file_get_contents('../htmlTemplate/index.html'); // Get the HTML content from the index.html file

    // Find and replace the URL
    $html = str_replace('https://youtube.com', $linkToLock, $html);

    $folderPath = createRandomFolder(); // Get the path to the created folder
    $filePath = $folderPath . '/index.html'; // Set the path to the index.html file
    
    file_put_contents($filePath, $html); // Create the index.html file with the modified HTML content
    
    return str_replace('../telegram', '/telegram', $filePath);
/*     return $filePath; // Return the path to the created index.html file
 */}

?>