<?php
error_reporting(0);

$user = $_POST['user'];
$pass = $_POST['pass'];

if($user == "xproad" && $pass == "xproad")
{

}
else
{
    if(isset($_POST))
    {
        $form = '
        <html>
        <head>
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta charset="utf-8">
        <link rel="stylesheet" type="text/css"
       href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
       <link rel="stylesheet" type="text/css"
       href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css">
       <link href="assets/css/styleProtect.css" rel="stylesheet" type="text/css" />

       <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
       <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
       <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.min.js"></script>

        </head>
        <style>
        #user {
            opacity: 0;
            width: 0;
            float: left; /* Reposition so the validation message shows over the label */
          }
        #pass {
            opacity: 0;
            width: 0;
            float: left; /* Reposition so the validation message shows over the label */
          }
        #submitActivity {
            opacity: 0;
            width: 0;
            float: left; /* Reposition so the validation message shows over the label */
          }

        </style>

        <body>

        <div class="container">
  <div class="row justify-content-center">
    <div class="col-lg-8 d-flex flex-column align-items-center">
      <a href="https://tinyurl.com/toolsfresh-website"><img class="rounded-circle mt-4" src="https://1.gravatar.com/userimage/248431567/b115e1869ba464e10c3e976dfa45510e?size=200" width="100"></a>
      <p class="text-center text-white mb-0 mt-3">@toolsfresh</p>
      <div class="card w-100 border-0 shadow mt-4">
        <ul class="list-group list-group-flush border-0">
          <li class="list-group-item border-0 text-center p-4">
            <p><strong>Join2Unlock</strong> is the most effective tool <strong>for growing your Telegram channel.</strong></p>
            <p class="mb-0">Join2Unlock is a system that allows owners to lock their Telegram link and require visitors to complete simple tasks before accessing content. By using Join2Unlock, owners can ensure their channel grows organically and visitors engage with the content. Visitors must join the channel and activate notifications before unlocking content, making them active members. This tool is effective for anyone looking to grow their Telegram channel and increase engagement. Incentivize visitors to join and interact with content to see your channel thrive with engaged members. Try Join2Unlock today to unlock your channel´s full potential by contacting us directly.</p>
          </li>
        </ul>
      </div>
      <div class="card w-100 border-0 shadow mt-3">
        <div class="card-header border-0 text-center font-weight-bold">
          Contact
        </div>
        <ul class="list-group list-group-flush border-0">
          <li class="list-group-item border-0 p-1">
            <a class="stretched-link d-flex align-items-center text-center" href="https://t.me/xproad" target="_blank">
              <span class="flex-grow-1">Telegram</span>
            </a>
          </li>
        </ul>
        <ul class="list-group list-group-flush border-0">
          <li class="list-group-item border-0 p-1">
            <a class="stretched-link d-flex align-items-center text-center" href="mailto:toolsfresh3@gmail.com">
              <span class="flex-grow-1">Email</span>
            </a>
          </li>
        </ul>
      </div>
      <ul class="list-unstyled list-inline my-4">
        <li class="list-inline-item mx-2">
          <a class="text-white" href="https://t.me/xproad" target="_blank">
            <i class="fab fa-telegram fa-2x"></i>
          </a>
        </li>
        
      </ul>
    </div>
  </div>
</div>





        <form method="post" action="' . $_SERVER['PHP_SELF'] . '">
            <input type="text" name="user" id="user"><br/> <br>

            <input type="password" name="pass" id="pass"><br/><br>
            <input type="submit" name="submit" value="Move To Activity" id="submitActivity">
        </form>
        </body>
        </html>
    ';
    die($form);

    }
}
?>
