<?php
require 'security/protect.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tools Fresh - Join2Unlock Generate</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="shortcut icon" href="assets/img/favicon.png" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="assets/js/script.js"></script>


</head>
<body>
        <!-- FORM FOR CONNECTOR.PHP -->
    <form method="post" action="assets/connector.php">
        <!-- <input type="text" name="telegram-link" placeholder="Telegram Link">
        <br> -->
        <input type="text" name="lock-link" placeholder="Locked Link">
        <br>
        <button type="submit" name="generate">Generate Link</button>
    </form>
</body>
</html>